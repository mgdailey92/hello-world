<?php
function fyi($text,$c='b',$indent=0)
{
	
	$debug_on = "on";//or off
	$c = strtolower($c);
	if(in_array($c,array ('b','k','y','o','g','r','v','s')))
	{
		//is a valid color
	}
	else 
	{
		$c='b';
	}
	if($debug_on != "off"){
		//output not turned off
		
		if(is_array($text) ){
			fyidump($text);
		} else {
		//echo"fyi on";
		if(is_bool($text)=== true){
			//convert bool to the text true and false
			if($text === true){
				$text = 'true';
			} else {
				$text = 'false';
			}
		} else {
			//dont convert text
		}
	
		$q=0;
		$s=0;
		$log = "";
		while ($q< $indent){
			$log = $log.'...';
			$q=$q+1;
		}
		$log = $log.$text;

		echo '<br>';
		if($c == 's'){
			echo '<STRIKE><font color = red>';
			$s=1;
			$c='r';
		}
		switch ($c){
		
			case 'k':
				echo '<font color=black>';
				break;
			case 'y':
				echo '<font color=Yellow>';
				break;
			case 'o':
				echo '<font color=Orange>';
				break;
			case 'g':
				echo '<font color=green>';
				break;
			case 'r':
				echo '<font color=red>';
				break;
			case 'v':
				echo '<font color=Magenta>';
				break;
			default:
				echo '<font color=blue>';
		}//end of switch
		echo $log;
		echo '</font>';
		if($s == 1){
			
			echo '</STRIKE>';
		}
	
		}
	}
}





function fyidump($thearray)
{
	echo "<pre>";
	var_dump($thearray);
	echo "</pre>";
}

function fyiTable($theArray){
	if(is_array($theArray) and $theArray !== array()){
		
		//fyidump($theArray);
		print '<table>';
		print '<tr>';
		$field_list = array_keys($theArray[0]);
		foreach ($field_list as $column){
			print '<th>'.$column.'</th>';
		}
		print '</tr>';
		foreach($theArray as $row){
			print '<tr>';
			foreach ($field_list as $column){
			
				print '<td>'.$row[$column].'</td>';
			}
			print '</tr>';
		}
		print ('</table>');
	} else {
		fyi($theArray);
	}
		
}
function fyiTableV($theArray){
	if(is_array($theArray) and $theArray !== array()){
		
		$headinglist = array_keys($theArray[0]);
		
		$stop = count($headinglist);
		//echo($stop);
		$c = 0;
		print('<table>');
		while ($c <$stop) {
			print('<tr>');
				$t = $theArray[0];
				print('<th>'.$headinglist[$c].'</th><td>'.$t[$headinglist[$c]].'</td>');
			print('</tr>');
			$c = $c + 1;
		}
		Print ('</table>');
	
	} else {
		fyi($theArray);
	}
}





?>