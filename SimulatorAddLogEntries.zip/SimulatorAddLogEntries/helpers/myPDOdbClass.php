<?php
//<!--- myPDOdbClass -->
include_once('CleanerClass.php');
include_once('fyi.php');
class myPDOdb
{
	
	public $connection_status = "";
	private $conn;
	public $var = "a default value";
	public $last_query = "";
	public $err = "";
	public $server ="";
	private $db;
	
	function __construct($DB_USER, $DB_PASS, $DB_HOST) {
			$db = "oci:dbname=".$DB_HOST;
			$this->server = $DB_HOST;
			$options = [
			PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
			PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
			PDO::ATTR_EMULATE_PREPARES   => false,
			];
		$out = "connection to ".$DB_HOST." working";
		//echo $DB_USER.' '.$DB_HOST.'<br>';
		try {
			$this->conn =  new PDO($db,$DB_USER,$DB_PASS,$options);
		} catch (PDOException $e) {
			$out = '<br>'.$e->getMessage().'<br>';
			
			if (isset($PRODUCTION) and $PRODUCTION = TRUE){
					//log error
					//todo send out to errorfile
			} else {
				echo ($out);
			}
		}
		$this->connection_status = $out;
		//echo $out;
	}

	
	
	/**
	*	runs a query
	*
	* Prevents most attacks	
	*	@parm string
	* @parm array(key value)  array('dname'=>'jim') or array('field'=>"'jim','frank','bob'")
	* @return array
	**/
	
	public function sql($query, $param = array()){
		$results= array();
		$x = array();
		$index = 0;
		$placeholders = array();
		//echo ('sql start');
		//var_dump($this->conn);
		$this->err = "";
		$the_sql = $query;// so I never change the original
		//var_dump($the_sql);
		//echo ('starting param: ');
		//var_dump ($param);
		try {
		$new_param = array();
		if (is_array($param)) {
			if($param != array()){ 
				//echo "<br>param not empty<br>";
				$index = 0;
				foreach ($param as $key => $val){
					//echo "<hr>";
					//echo "<br>".$key." param[key]: ".$param[$key];
					//echo "<br> val: ".$val;
					//does the parameter contain a list like "'xxx','yyyy','zzzz'"
					if (is_array($val) === true){
						//fyi('val is array');
						$x = $val;
					} else {
						//fyi('val is not an array');
						if(strpos(strtoupper($query),' IN(') !== false or strpos(strtoupper($query),' IN (') !== false){ 
							//fyi('query has IN ');
							$x = Cleaner::delimitedStringToArray($val);
						} else {
							$x = array();
							$x[] = $val;
						}
					}
					$countx = count($x);
					//fyi($x);
					//fyi(' count ='.$countx);
					if( $countx === 1){
						//fyi('no list found');
						$bind[$key] = $x[0];//bind the param 
					} else {
						//fyi('found a list create bindings for each member of list');
						foreach ($x as $value){
							//fyi('value:'.$value);
							$placeholders[] = ':filter'.$index;
							$bind['filter'.$index++] = $value;
						}	
						if ($index > 999) {
									throw new Exception('To many items in '.substr($val,0,255));
						}
						//fyi('before sql');
						//fyi($the_sql);
						//fyi('key:'.$key);
						$key = ltrim($key,':');//remove : if it exist so we can add it back
						//echo("<br> placeholderlist: ".$placeholderlist);
						$key = ':'.$key;// needed this to get rid of the colon
						$placeholderlist  = implode(', ',$placeholders);
						$the_sql = str_replace($key,$placeholderlist,$the_sql);
						
					}
					//fyi('<br>after sql:'.$the_sql);
					$new_param = array_merge($new_param,$bind);
					//echo("<br> new_param: ");
					//print_r($new_param);
				} 
			} else {
				//no params
			}
		} else {
			//params not an array ignore params
		}
		} catch (Exception $e){
			echo 'Caught excetion:' , $e->getMesage(),"<br>";
			
		}
		//echo('<br>the_sql<br>');
		//echo $the_sql;
		//echo ('<br>New Param<br>');
		//var_dump ($new_param);
		$this->last_query = self::sqlToDebugString($the_sql,$new_param)." -- query: ".$the_sql." params: ".serialize($new_param);
		//echo ("<br>");
		//echo $this->last_query;
		//echo ("<br>");
		//echo ('<hr>');
	
		try {
			if( is_array($new_param) ){
				//if( is_array($new_param) and $new_param != array()){
				//echo('<br>new param<br>');
				$stid = $this->conn->prepare($the_sql);
				$stid -> execute($new_param);
			} else {
				//echo('<br> no params<br>');
				$stid = $this->conn->query($the_sql);
			}
			
			//echo $stid->errorCode();
			 $foo_arr = $stid->errorInfo();
			 if(isset($foo_arr[1]) and $foo_arr[1] != 0){
				
				print_r($foo_arr);
				print_r('the sql');
				print_r($the_sql);
				print_r('new_param');
				print_r($new_param);
			 }
			if (strtoupper(substr($the_sql,0,6)) =='INSERT' or strtoupper(substr($the_sql,0,6)) =='UPDATE' or strtoupper(substr($the_sql,0,6)) =='DELETE'){// check for insert
				$results[]= 1; // I was getting an error trying to walk the results after an insert
				
			} else {
				//echo ('
				foreach($stid as $row) {
				//echo('<br> row:');
				//var_dump($row);
				$results[] = $row;
				//echo('<br>');
				}
			}
			
			
		} catch (\PDOException $e) {
			//echo('<br>had an error'.$e->getMessage());
			$this->err = $e->getMessage();
			$out = '<b>'.$e->getMessage().'<br>'.$this->last_query;
			//fyi($out,'r');
			/*
			$foo_arr = $stid->errorInfo();
			 if(isset($foo_arr[1]) and $foo_arr[1] != 0){
				
				print_r($foo_arr);
				print_r('the sql');
				print_r($the_sql);
				print_r('new_param');
				print_r($new_param);
			 }
			 */
			//if ($GLOBALS['PRODUCTION']){
					//log error
					//todo send out to errorfile
			//} else {
				$results = $out;
			//}
		}
		//echo('<br>sql execute:');
	
		
		//echo('<br>Results:<br>');
		//var_dump($results);
		//echo '<br> last query: ';
		//echo $this->last_query;
		return $results;
			
		
		
	
	}
	
	public function getLastQuery(){
		return $this->last_query;
	}
	
	public static function sqlToDebugString($query,$param){
			//echo('<br>sqlToDebugString Query:'.$query);
			//echo ('<br>');
			//var_dump($param);
		$out = "";
		$out = $query;
		if ($param !== ''){
			Foreach ($param as $key =>$val) {
				//echo('<br>key:'.$key);
				//echo ('<br>val:'.$val);
				if (substr($key,0,1) == ':' ){
					// dont add the :
				} else {
					$key = ":".$key;
				}
				$out = str_replace($key,"'".$val."'",$out);
			}
		} else {
			echo ('<br>no param</br>');
			$out = $query;
		}
		//echo('<br> sqlToDebugString out:<br>');
		//echo $out.'<br>';
		return $out;
	}
	
	// end of core function
	
	
	/**
	*	tests connection to esoms
	*
	* Prevents most attacks	
	*	@parm string
	* @return string
	**/
	public function testConnection(){
		
		//echo '<br>'.$this->connection_status;
		
		return $this->connection_status;
	}
	
	public function tests(){
		//fyi('myPDOdbClassTests');
		
		$out = "";
		$tclass = 'pass';
		//tests

		//note to self when using the in  function the paramiter list must be csv (no spaces between the comma and the next value)
		$ctests = array(
		
			array("funct"=>"testConnection","testname"=>"test Connection","input"=>"", "expected"=>"connection to WTP_NNDB_P working"),
			array("funct"=>"sql","testname"=>"test sql no paramiters","input"=>array("select * from nn_config where config = 'OFF'",""), "expected"=>'a:1:{i:0;a:1:{s:6:"CONFIG";s:3:"OFF";}}'),
			array("funct"=>"sql","testname"=>"test sql ONE paramiters","input"=>array("select * from 
			nn_config where config = :id",array(":id"=>"OFF")), "expected"=>'a:1:{i:0;a:1:{s:6:"CONFIG";s:3:"OFF";}}'),
		array("funct"=>"sql","testname"=>"test sql no paramiters two","input"=>array("select full_name from nn_abbr where abbr = '1ST' and approved = '-1' ",""), "expected"=>'a:1:{i:0;a:1:{s:9:"FULL_NAME";s:5:"First";}}'),
			array("funct"=>"sql","testname"=>"test sql two paramiters","input"=>array("select full_name from nn_abbr where abbr = :abbr and approved = :appr ",array(":abbr"=>"1ST",":appr"=>"-1")), "expected"=>'a:1:{i:0;a:1:{s:9:"FULL_NAME";s:5:"First";}}'),
			array("funct"=>"sql","testname"=>"test sql null return paramiters","input"=>array("select full_name from nn_abbr where abbr = '1STTTTTTT' and approved = '-1' ",""), "expected"=>'a:0:{}'),
			//array("funct"=>"sql","testname"=>"test sql error return","input"=>array("select This_should_Throw_a_warning from nn_abbr where abbr = '1STTTTTTT' and approved = '-1' ",""), "expected"=>'SQLSTATE[HY000]: General error: 904 OCIStmtExecute: ORA-00904: "THIS_SHOULD_THROW_A_WARNING": '),
			
			array("funct"=>"sql","testname"=>"test sql IN test","input"=>array("select noun_name from nn_noun_name where ctn in( :list )",array("list"=>"'24590-BOF-PV-SCW-V-70735-X','24590-BOF-PV-SCW-V-70735-Y'")), "expected"=>'a:2:{i:0;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL OUT";}i:1;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL INL";}}'),
			
			array("funct"=>"sql","testname"=>"test sql IN test2","input"=>array("select noun_name from nn_noun_name where active = :active and  ctn in( :list )",array("list"=>"'24590-BOF-PV-SCW-V-70735-X','24590-BOF-PV-SCW-V-70735-Y'","active"=>"-1")), "expected"=>'a:2:{i:0;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL OUT";}i:1;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL INL";}}'),
			array("funct"=>"sql","testname"=>"test sql IN test3","input"=>array("select noun_name from nn_noun_name where active = :active and  ctn in( :list )",array("list"=>"24590-BOF-PV-SCW-V-70735-X|24590-BOF-PV-SCW-V-70735-Y","active"=>"-1")), "expected"=>'a:2:{i:0;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL OUT";}i:1;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL INL";}}'),
			array("funct"=>"sql","testname"=>"test sql IN test4","input"=>array("select noun_name from nn_noun_name where active = :active and  ctn in ( :list )",array("list"=>"24590-BOF-PV-SCW-V-70735-X|24590-BOF-PV-SCW-V-70735-Y","active"=>"-1")), "expected"=>'a:2:{i:0;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL OUT";}i:1;a:1:{s:9:"NOUN_NAME";s:41:"STM PLANT COND XFER PMP A RECIRC ISOL INL";}}'),
			//array("funct"=>"sqlToDebugString","testname"=>"test sqlToDebugString","input"=>array("select * from nn_config where config = :id",array("id"=>"OFF")), "expected"=>"select * from nn_config where config = 'OFF'"),
		);
		//output
		print("<h2>my pdo db test start</h2>");//name of class
		print '<table>';
		print '<tr>';
		print '<th> Function </th><th>Test Name</th><th>input</th><th>expected</th><th>output</th><th>pass/fail</th>';
		print '</tr>';
		//work through each test
		foreach ( $ctests  as $test){
			//echo '<br>'.$test['testname'];
			$nname = $test["funct"];
			if( is_array($test['input'])){
				$count = count($test['input']);
				$i= serialize($test['input']);
				switch($count){
					case 1:
						$output = self::$nname($test['input'][0]);
						break;
				 case 2:
				 		$output = self::$nname($test['input'][0], $test['input'][1]);
				 		break;
				 default:
				 		echo ('Not supported test'); 
				}
			} else { 
				$i = $test['input'];
				$output = self::$nname($test['input']);//self because it is a static method
			}
			if (is_array($output)) {
				$output = serialize($output);
				
			}
			//echo('<br>');
			//var_dump($output);
			if($output <> $test['expected']){
					$out = 'Fail';
					$tclass = 'fail';
			} else {
					$out = 'Pass';
					$tclass = 'pass';
			} 
			print '<tr class='.$tclass.'>';
			print '<td>'.$test['funct'].'</td><td>'.$test['testname'].'</td><td>'.$i.'</td><td>'.$test['expected'].'</td><td>'.$output.'</td><td>'.$out.'</td>';
			if ($this->err !== ""){
					$output.'<span style="color: red;"><br>'.$this->err.'</span>';
			} else {
			}
			print '</tr>';
		} // end of foreach
		print '</table>';
		
		print ("<hr>");// end of the test
	}
	
}

class query{
	public $sql='';
	public $params = array();
	public $undo_params = array();
	public $undo_sql = '';
	
	function __construct(string $sql = '',array $params = array(),array $undo_params = array(),string $undo_sql = ''){
		$this->sql = $sql;
		foreach($params as $key =>$value){
			$this->params[$key] = $value;
		}
		foreach($undo_params as $key => $value){
			$this->undo_params[$key] = $value;
		}
		$this->undo_sql = $undo_sql;
	}
	public function set_all($sql,$params,$undo_params){
		
		$this->sql = $sql;
		foreach($params as $key =>$value){
			$this->params[$key] = $value;
		}
		foreach($undo_params as $key => $value){
			$this->undo_params[$key] = $value;
		}
		
	}
	public function toString(){
		$out = '';
		$out ='<br>query: <br>'.$this->sql;
		$out .='<br> params';
		
		foreach($this->params as $key => $value){
			$out .='<br>'.$key.' '.$value;
		};
		$out .='<br> undo params:';
		foreach($this->undo_params as $key => $value){
			$out .='<br>'.$key.' '.$value;
		};
		$out .='<br>'.$this->undo_sql;
		return $out;
	}
	 public function ToDebugString($do = true){
		 if($do == true) {
			 $out = myPDOdb::sqlToDebugString($this->sql,$this->params);
		 } else  {
			 if ($this->undo_sql == ""){
				 $out = myPDOdb::sqlToDebugString($this->sql,$this->undo_params);
			 } else  {
				$out = myPDOdb::sqlToDebugString($this->undo_sql,$this->undo_params);
			 }
		 }
		 return $out;
	 }
	
	function test(){
		$t = new query;
		
		$t->sql = 'select * from nndb where ctn = :CTN';
		$t->params = array(':CTN'=>'24590-BOF-PV-DFO-V-90651');
		$t->undo_params = array();
		print ($t->ToDebugString());
	}
}

//end of query class
?>

