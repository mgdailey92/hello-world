<?php
//<!--- esoms class  runs queries on esoms db-->
require_once('myPDOdbClass.php');
class esoms  extends myPDOdb
{
	
	/*
	function __construct($DB_USER, $DB_PASS, $DB_HOST) {
		//inherited from myPDOdb
	}
	*/
	
	/**
	*	runs a query on the esoms
	*
	* Prevents most attacks	
	*	@parm string
	* @parm array(key value) key starts with a :  like ':dname' array(':dname'=>'jim')
	* @return array
	**/
	/*
	
		
	
	}
	
	public function getLastQuery(){
		return $this->Last_query;
	}
	
	public function sqlToDebugString($query,$param){	
		$out = "";
		$out = $query;
		if ($param !== ''){
			Foreach ($param as $key =>$val) {
				$out = str_replace($key,"'".$val."'",$out);
			}
		} else {
			$out = $query;
		}
		return $out;
	}
	
	// end of core function
		/**
	*	tests connection to esoms
	*
	* Prevents most attacks	
	*	@parm array of vtns
	* @return array of equip
	**/
	public function findEquipByVTN($vtns, $site_code = '1     '){
		if (strlen($site_code) < 6) {
			$site_code = str_pad($site_code, 6," ",STR_PAD_RIGHT);
		}
		$sql = "select EQUIP_OPERATOR_ID from equip where EQUIP_OPERATOR_ID in (:vtns) and site_code = :site_code ";
		$params = array(":vtns"=>$vtns, ":site_code"=>$site_code);
		$result = $this->sql($sql,$params);
		//echo('<br>Result:');
		//var_dump($result);
		//echo '<br> bob <br>';
		//echo $this->last_query;
		Return $result;
	}
	

	/**
	*	tests connection to esoms
	*
	* Prevents most attacks	
	*	@parm string
	* @return string
	**/
	public function testConnection(){
		//echo '<br>'.$this->connection_status;
		return $this->connection_status;
	}
	
	public function tests($db_option=""){
		$out = "";
		$tclass = 'pass';
		//tests
		if($db_option ==='sync'){
			$ctests = array(
			array("funct"=>"testConnection",
				"testname"=>"test Connection",
				"input"=>"", 
				"expected"=>"connection to WTP_POMS_TR working"),
			array("funct"=>"sql",
				"testname"=>"insert",
				"input"=>"INSERT INTO WTP_ESOMS_SYNC.SPECIAL_REPORTS 
					(REPORT_NAME,REPORT_SQL, REPORT_PARAM, REPORT_HEADERLIST, REPORT_FIELDLIST, SORT_ORDER,ACTIVE) 
					VALUES 
					('TEST_REPORT','SELECT * FROM SPECIAL_REPORTS WHERE REPORT_ID = :REPORT_ID',':REPORT_ID|1','REPORT_NAME','REPORT_NAME',1,1) ",
				"expected"=>'a:1:{i:0;i:1;}'),
			array("funct"=>"sql","testname"=>"test sql two paramiters update","input"=>array("update VISION_TO_ESOMS_STANDARD_ENTRY SET updated = :UPDATED Where T_ID = :T_ID",array(":UPDATED"=>"C",":T_ID"=>"1")), "expected"=>'a:1:{i:0;i:1;}'),
			
			
			);
		} else {
		
			$ctests = array(
			
			array("funct"=>"testConnection","testname"=>"test Connection","input"=>"", "expected"=>"connection to WTP_POMS_TR working"),
			array("funct"=>"sql","testname"=>"test sql no paramiters","input"=>array("select site_code from somsdba.sites where site_code = '1'",""), "expected"=>'a:1:{i:0;a:1:{s:9:"SITE_CODE";s:6:"1     ";}}'),
			array("funct"=>"sql","testname"=>"test sql 1 paramiter","input"=>array("select site_code from somsdba.sites where site_code = :id ",array(":id"=>"1     ")), "expected"=>'a:1:{i:0;a:1:{s:9:"SITE_CODE";s:6:"1     ";}}'),
			
			array("funct"=>"sql","testname"=>"test sql ONE paramiterslist","input"=>array("select EQUIP_OPERATOR_ID from equip where EQUIP_OPERATOR_ID in (:vtns)",array("vtns"=>"'BAD-V-VTN','NAR-V-10992'")), "expected"=>'a:1:{i:0;a:1:{s:17:"EQUIP_OPERATOR_ID";s:11:"NAR-V-10992";}}'),
			
			array("funct"=>"sql","testname"=>"test sql list and one", "input"=>array("select equip_operator_id from equip where site_code = :site_code and  equip_operator_id in (:vtns)", array("vtns"=>"'BAD-V-VTN','NAR-V-10992'","site_code"=>"1     ")), "expected"=> 'a:1:{i:0;a:1:{s:17:"EQUIP_OPERATOR_ID";s:11:"NAR-V-10992";}}'),
			array("funct"=>"findEquipByVTN","testname"=>"find Equip By VTN #1","input"=>"NAR-V-10992","expected" =>'a:1:{i:0;a:1:{s:17:"EQUIP_OPERATOR_ID";s:11:"NAR-V-10992";}}'),
			array("funct"=>"findEquipByVTN","testname"=>"find Equip By VTN #2",
				"input"=>array("NAR-V-10992","1 "),
				"expected" =>'a:1:{i:0;a:1:{s:17:"EQUIP_OPERATOR_ID";s:11:"NAR-V-10992";}}'),
			
			);
		}
		//output
		print("<h2>esoms test start</h2>");//name of class
		print '<table>';
		print '<tr>';
		print '<th> Function </th><th>Test Name</th><th>input</th><th>expected</th><th>output</th><th>pass/fail</th>';
		print '</tr>';
		//work through each test
		foreach ( $ctests  as $test){
			//echo '<br>'.$test['testname'];
			$nname = $test["funct"];
			if( is_array($test['input'])){
				$count = count($test['input']);
				$i= serialize($test['input']);
				switch($count){
					case 1:
						$output = self::$nname($test['input'][0]);
						break;
					case 2:
				 		$output = self::$nname($test['input'][0], $test['input'][1]);
				 		break;
					default:
				 		echo ('Not supported test'); 
				}
			} else { 
				$i = $test['input'];
				$output = self::$nname($test['input']);//self because it is a static method
			}
			if (is_array($output)) {
				$output = serialize($output);
				
			}
			//echo('<br>');
			//var_dump($output);
			if($output <> $test['expected']){
					$out = 'Fail';
					$tclass = 'fail';
			} else {
					$out = 'Pass';
					$tclass = 'pass';
			} 
			print '<tr class='.$tclass.'>';
			print '<td>'.$test['funct'].'</td><td>'.$test['testname'].'</td><td>'.$i.'</td><td>'.$test['expected'].'</td><td>'.$output.'</td><td>'.$out.'</td>';
			if ($this->err !== ""){
					print ('<span style="color: red;"><br>.$this->err</span>');
			} else {
			}
			print '</tr>';
		} // end of foreach
		print '</table>';
		
		print ("<hr>");// end of the test
	}
	
}
?>

