<?php
class Cleaner
{
	/**
	*	Cleans input from most bad input
	*
	* Prevents most attacks	
	*   This is the most common function called
	*	@parm string
	* @return string
	**/
	public static function cleanInput($str) {
		$str = trim($str);
		$str = stripslashes($str);
 	 	$str = htmlspecialchars($str);
		$str = self::remove_invisible_characters($str);
  	return $str;
	}
	public static function cleanInputLimited($str) {
		$str = trim($str);
		$str = stripslashes($str);
 	 	
		$str = self::remove_invisible_characters($str);
  	return $str;
	}
	
	/**
	 * Remove Invisible Characters based on codeigniter's 
	 *
	 * This prevents sandwiching null characters
	 * between ascii characters, like Java\0script.
	 *
	 * @param	string
	 * @param	bool
	 * @return	string
	 */
	public static function remove_invisible_characters($str, $url_encoded = TRUE)
	{
		$non_displayables = array();
		// every control character except newline (dec 10),
		// carriage return (dec 13) and horizontal tab (dec 09)
		if ($url_encoded)
		{
			$non_displayables[] = '/%0[0-8bcef]/i';	// url encoded 00-08, 11, 12, 14, 15
			$non_displayables[] = '/%1[0-9a-f]/i';	// url encoded 16-31
			$non_displayables[] = '/%7f/i';	// url encoded 127
		}
		$non_displayables[] = '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+/S';	// 00-08, 11, 12, 14-31, 127
		do
		{
			$str = preg_replace($non_displayables, '', $str, -1, $count);
		}
		while ($count);
		
		return $str;
	}
	/**
	 * Remove Invisible Characters based on codeigniter's 
	 *
	 * .
	 *
	 * @param	string
	 *
	 * @return	string
	 */
	public static function delimitedStringToArray($str){
		$out = array();
		if(strlen($str) <2){
			$out[] =$str;
			return $out;// skip the function
		} else {
			//ok to continue;
		}
		//fyi('find what is delimited the string');
		$delimiter = array("|","_",",",'	',",","\n",chr(13).chr(10));
		//var_dump($delimiter);
		$found = FALSE;
		$firstdelimiterPos = -1;
		
		foreach ($delimiter as $d){
			//echo ('d: '.$d);
			$firstdelimiterPos = strpos($str,$d);
			//echo ' firstdelimiterPos :';
			//var_dump($firstdelimiterPos);
			
			if ($firstdelimiterPos === FALSE) {
					//not found
			} else {
					//found
					$delimiter  = $d;
					$found = TRUE;
					break;
			}
		}
		//echo ('found: ');
		//var_dump($found);
		if($found === true) {
			//explode on delimiter
			if ( $delimiter === ",") {
				//csv
				//echo('got to CSV with delimiter:'.$d.'<br>');
				$out = str_getcsv($str,",",'"');
				//trim each element
				$new_out = array();
				foreach ($out as $element){
					//fyi('element='.$element);
					//trim leading or trailing '
					$t = trim($element);
					$t = rtrim($t,"'");
					$t = ltrim($t,"'");
					//fyi('t='.$t);
					$new_out[] = $t;
				}
				$out = $new_out;
			} else {
				//echo('got to explode with delimiter:'.$d.'<br>');
				$out = explode($delimiter, str_replace("\r", "", $str));
				//$out = explode($delimiter,$str);
			}
		} else  {
			//no delimter found return string as first element of array
			//fyi('no delimiter found');
			$out[] = $str;
		}
		return $out;
	}
	
	/**
	*	unit test for this class
	* jcclegg's first attempt at unit testing without access to command line
	*/
	public static function tests(){
		
		$out = "";
		$tclass = 'pass';
		//tests
		$ctests = array(
			array("funct"=>"cleanInput","testname"=>"Clean Text","input"=>"goodinput", "expected"=>"goodinput"),
			array("funct"=>"cleanInput","testname"=>"Slashes","input"=>"O\'reilly","expected"=>"O'reilly"),
			array("funct"=>"cleanInput","testname"=>"Trim","input"=>"  extraspace   ","expected"=>"extraspace"),
			array("funct"=>"cleanInput","testname"=>"backslash0","input"=>array("Java\0script",TRUE),"expected"=>"Javascript"),
			array("funct"=>"cleanInput","testname"=>"backslash0","input"=>array("Java\0script",FALSE),"expected"=>"Javascript"),
			array("funct"=>"remove_invisible_characters","testname"=>"backslash0","input"=>array("Java\0script",TRUE),"expected"=>"Javascript"),
			array("funct"=>"remove_invisible_characters","testname"=>"backslash0","input"=>array("Java\0script",FALSE),"expected"=>"Javascript"),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArray|","input"=>"bob|SAM|Sally","expected"=>'a:3:{i:0;s:3:"bob";i:1;s:3:"SAM";i:2;s:5:"Sally";}'),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArray_","input"=>"bob_SAM_Sally","expected"=>'a:3:{i:0;s:3:"bob";i:1;s:3:"SAM";i:2;s:5:"Sally";}'),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArray,","input"=>'bob,sally,"sam,rob",samth\'a"',"expected"=>'a:4:{i:0;s:3:"bob";i:1;s:5:"sally";i:2;s:7:"sam,rob";i:3;s:8:"samth\'a"";}'),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArray,2","input"=>'BAG-V-00271,BAG-V-00271,BAG-V-00271',"expected"=>'a:3:{i:0;s:11:"BAG-V-00271";i:1;s:11:"BAG-V-00271";i:2;s:11:"BAG-V-00271";}'),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArray,3","input"=>'BAG-V-00271, BAG-V-00271, BAG-V-00271',"expected"=>'a:3:{i:0;s:11:"BAG-V-00271";i:1;s:11:"BAG-V-00271";i:2;s:11:"BAG-V-00271";}'),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArraynone","input"=>'BAG-V-00271',"expected"=>'a:1:{i:0;s:11:"BAG-V-00271";}'),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArraytab","input"=>'BAG-V-00271	BAG-V-00255',"expected"=>'a:2:{i:0;s:11:"BAG-V-00271";i:1;s:11:"BAG-V-00255";}'),
			array("funct"=>"delimitedStringToArray","testname"=>"delimitedToArrayexcel","input"=>'24590-BOF-JA-SDJ-PNL-00137-V-01'.chr(13).chr(10).'24590-BOF-JA-SDJ-PNL-00137-V-02'.chr(13).chr(10).'24590-BOF-JA-SDJ-PNL-00137-V-0'.chr(13).chr(10).'24590-BOF-JA-SDJ-PNL-00137-V-04'.chr(13).chr(10).'24590-BOF-JA-SDJ-PNL-00137-V-05',"expected"=>'a:5:{i:0;s:31:"24590-BOF-JA-SDJ-PNL-00137-V-01";i:1;s:31:"24590-BOF-JA-SDJ-PNL-00137-V-02";i:2;s:30:"24590-BOF-JA-SDJ-PNL-00137-V-0";i:3;s:31:"24590-BOF-JA-SDJ-PNL-00137-V-04";i:4;s:31:"24590-BOF-JA-SDJ-PNL-00137-V-05";}'),
			
			
			
		);
		//output
		print("<h2>Clearer class test start</h2>");//name of class
		print '<table>';
		print '<tr>';
		print '<th> Function </th><th>Test Name</th><th>input</th><th>expected</th><th>output</th><th>pass/fail</th>';
		print '</tr>';
		//work through each test
		foreach ( $ctests  as $test){
			$nname = $test["funct"];
			if( is_array($test['input'])){
				$count = count($test['input']);
				$i= serialize($test['input']);
				switch($count){
					case 1:
						$output = self::$nname($test['input'][0]);
						break;
				 case 2:
				 		$output = self::$nname($test['input'][0], $test['input'][1]);
				 		break;
				 default:
				 		echo ('Not supported test'); 
				}
			} else { 
				$i = $test['input'];
				$output = self::$nname($test['input']);//self because it is a static method
			}
			if (is_array($output)) {
				$output = serialize($output);
				
			}
			//var_dump($output);
			if($output <> $test['expected']){
					$out = 'Fail';
					$tclass = 'fail';
			} else {
					$out = 'Pass';
					$tclass = 'pass';
			} 
			print '<tr class='.$tclass.'>';
			print '<td>'.$test['funct'].'</td><td>'.$test['testname'].'</td><td>'.$i.'</td><td>'.$test['expected'].'</td><td>'.$output.'</td><td>'.$out.'</td>';
			print '</tr>';
		}
		print '</table>';
		
		print ("<hr>");// end of the test
	}
	
}