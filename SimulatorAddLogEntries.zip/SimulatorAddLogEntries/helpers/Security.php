<?php
include_once ('CleanerClass.php');
include_once('fyi.php');
/*
* security helpers
* Reads Global $_POST 
* $required array of required fields in the $_POST
* $optional array of optional fields in the $_POST
* $optiona_array is array of arrays(one dimentional arrays) 
* check arrays this only supports one dimentional arrays
* compare cleaned to original if they don't match it fails 
* returns an array $post_data with the cleaned input from the $_POST
* $post_data['ERROR'] contains any errors found in cleaning $_POST
*/
function validateFields($required,$optional,$optional_arrays=array()){
	$is_valid = true;
	$post_data = array('ERROR'=>"");
	$reason_not_valid = '';
	$error = 'Security validateFields<br>';
	//do we have all the fields
	try {
		//what fields are required on post
		$all_required_in_post = true;
		$missing_in_post = "<br>error invaled post, missing required values ";// error message
		foreach ($required as $req) {
			if(!isset($_POST[$req]) ){
				$missing_in_post = $missing_in_post.' '.$req;
				$all_required_in_post = false;
				$is_valid = false;
			} else {
				// ok to proceed
			}
		}
		if($all_required_in_post === false){
			
			$error = $error.$missing_in_post.'<br>Post:<br>';
			$reason_not_valid .= $missing_in_post;
			$error = $error.serialize($_POST);
			$is_valid = false;
			error_page($error);
			//exit;
		} else {
			// all requred are in post
		}
	} catch (Exception $e) { 
		//unserializing an non array was one error I found in testing
		$post_data["ERROR"] .= '<br>'.$e->getMessage();
		$is_valid = false;
	}
	
	//clean input
	$post_data = array('ERROR'=>"");
	$valid = true;
	foreach ($required as $req) {
		$temp = Cleaner::cleanInput(($_POST[$req]));//for non arrays
		if ($temp != ($_POST[$req])){
			
			$error = $error.'not equal<br>';
			
			$error = $error.'temp:';
			$error = $error.$temp;
			$error = $error.'<br>post '.$req.' :'.$_POST[$req].'<br>';
			$opcodes = FineDiff::getDiffOpcodes($_POST[$req], $temp /* , default granularity is set to character */);
			//fyi('opcodes: '.$opcodes);
			$edit_distance = FineDiff::editDistance($opcodes);//number of changes to make one string = the other;
			$what_is_different_styled = FineDiff::renderDiffToHTMLFromOpcodes($_POST[$req], $opcodes);
			$error = $error.$what_is_different_styled;
			$valid = false;
			$reason_not_valid .= ' CORUPT '. $req.' SENT';
			$error = $error.'<br>'.$reasons_not_valid;
			error_page($error);
			//exit;
		} else {
			$post_data[$req] = $temp;
		}
	}

	foreach ($optional as $opt) {
		//fyi('opt');
		//fyi($opt);
		
		if(isset($_POST[$opt])){
			$temp = Cleaner::cleanInput(($_POST[$opt]));//for non arrays
			if ($temp != ($_POST[$opt])){
				$error = $error.$opt.' not equal';
				$error = $error.'<br>temp: ';
				$error = $error.$temp.'<br>';
				$error = $error.'<br>post:';
				$error = $error.$_POST[$opt].'<br>';
				$valid = false;
				$reason_not_valid .= ' CORUPT '. $req.' SENT';
				$error = $error.$reason_not_valid;
				error_page($error);
				//exit;
			} else {
				$post_data[$opt] = $temp;
			}
		} else {
			//optional item not in post
		}
		
	} 
		
	//check arrays this only supports one dimentional arrays
	//todo add this checking
	$array_ok = true;
	foreach($optional_arrays as $a){
		//does the array exist
		//fyi($a);
		if(isset($_POST[$a])){
			$before = $_POST[$a];
			foreach ($before  as $item){
				//fyi('Item: '.$item);
				$temp = Cleaner::cleanInput(($item));//for non arrays
				//	$temp = $item ;
				if ($temp != $item) {
					$array_ok = false;
					$error = $error.serialize($a);
					$error = $error.serialize($temp);
					$error = $error.serialize($item);
					$error = $error.'array cleaner problem';
					error_page($error);
				} else {
					$post_data[$a][] = $temp;
				}
			}
		} else {
			//fyi('not set');
		}
	}
	//fyi($post_data);
	$post_data["ERROR"] =$reason_not_valid;
	if($valid !== true or $is_valid !== true){
		$post_data['valid'] = false;
	} else {
		$post_data['valid'] = true;
	}	
	return $post_data;
}
// payload validation
//since the payload may have arrays and other special data 
//Sometimes you need to just serialize it and do a check sum
//note we create the checksum before htmlentities

/*
//prepare the payload 
//$the_payload must be of a type of data that supports serialize
//returns an array $out['payload'] serialization of $the_payload, $out['checksum']
*/
function prepPayload($the_payload){
	$out = array();
	$payload = serialize($the_payload);
	$checksum = crc32($payload);
	$payload = htmlentities($payload, ENT_QUOTES, "UTF-8");// not check sum is computed before htmlentities
	$out['payload'] = $payload;
	$out['checksum'] = $checksum;
	return $out;
}
//checks the payload vs the checksum sent with the 

function validatePayload($the_payload, $checksum){
	//'this function needs beefed up'
	$out = false;
	$payload = html_entity_decode($the_payload, ENT_QUOTES, "UTF-8");
	$checksumtest = crc32($payload);
	if($checksumtest == $checksum){
		$out = true;
	} else {
		$out = false;
	}
	return $out;
}
/*
//extracs the data from the payload
* undoes the prepPayload
* returns the payload in its original form
*/
function extractPayload($the_payload){
	$out = html_entity_decode($the_payload, ENT_QUOTES, "UTF-8");
	$out = unserialize($out);
	return $out;
}
/*
Code to check for Double Submit
if there is a double submitt sends the user to the error_page

*/
function securityDoubleSubmitCheck(){
	//check for double submit
	$error = 'Security securityDoubleSubmitCheck<br>';
	$bad_submit = false;
	if (isset($_SESSION['loadat'])) {
		if (isset($_POST['loadat'])) {
			if ($_POST['loadat'] != $_SESSION['loadat']) {
				// double submit
				$bad_submit = true;
				$error = $error."Double Submit ";
				$error = $error.'<br>post:'.$_POST['loadat'];
				$error = $error.'<br>Sess:'.$_SESSION['loadat'];
				error_page($error);
			} else {
				//	 echo 'normal submit';
			}
		} else {
			$bad_submit =true;
			$error = $error.'error not loadat in post';
			error_page($error);
		}
	} else {
		$bad_submit = true;
		$error = $error.'error no session loadat';
		error_page($error);
	}
	if ($bad_submit === true){
		$error = $error.'bad_submit';
		error_page($error);
		//echo '<BR>bad_submit';
		//exit;
	}
}

/* create the token to be sent a a hidden variable
a call to this should be on every page with a <form
*/
function SecurityDoubleSubmitToken(){
	$_SESSION["loadat"] = rand(0,200000);// used to catch double posts
	Print '<input type ="hidden" name = "loadat" value="'.$_SESSION["loadat"].'"/>';
}
/*
Error page code
$data will be diplayed 
*/
function error_page($data){
	
	print '<h1 class="bad">Error</h1>';
	print '<br><br><br>';
	print_r ($data);
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION['which_server']?>" />	
		<div class="buttons">
			<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add logs
			</button>
		</div>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}


