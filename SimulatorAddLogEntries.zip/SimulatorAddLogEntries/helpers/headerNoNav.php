<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <!--<link rel="stylesheet" type="text/css" href="./css/base.css">-->
	<link rel="stylesheet" type="text/css" href="./css/wtpesoms.css">
    <!--<meta http-equiv="X-UA-Compatible" content="IE=edge">   I want to avoid forcing using ie !>
    <meta name="viewport" content="width=device-width, initial-scale=1">-->

    <title>WTP Operations Training &amp; eSOMS Sync </title>

    
    <!--<link href="css/userSync.css" rel="stylesheet">
  
    <link href="css/print.css" rel="stylesheet" media="print" type="text/css">
    -->
   <?php 
	if(isset($header_include)) {
		print $header_include; 
	}  else {
	  //do nothing
	}
	include_once('conn.php');
   ?>
</head>
<body>
		<nav>Simulator Add Logs</nav>
    <div>