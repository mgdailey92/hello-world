         
    </div><!-- end of main-->

<!--    <script src="/operations/js/jquery.min.js"></script> -->
    <!--<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>-->
 <!--   <script src="/operations/js/moment.js"></script> -->
  <!--  <script src="/operations/js/bootstrap.min.js"></script>
    <script src="/operations/js/bootstrap.datepicker.js"></script>
    <script src="/operations/js/core.js"></script> -->
  <!--  <? if(isset($footer_include)) { print $footer_include; } ?> -->
 <!--   <script src="js/report.js"></script> -->
</body>
</html>