<?php
error_reporting(E_ALL);	
ini_set('display_errors', '1');
date_default_timezone_set('America/Los_Angeles');
function pre($r) {
    print '<pre>' . htmlentities(print_r($r, true)) . '</pre>';	
}

if(file_exists('./settings.ini')) {
    $settings = parse_ini_file('./settings.ini');
    extract($settings);
}

function trunc($text, $l = 50) {
    if(strlen($text) < $l) {
        return $text;
    }
    return substr($text, 0, $l) . '...';
}

function json($arr, $exit = true) {
    header('Content-Type: application/json');
    print json_encode($arr);
    if($exit) exit;
}

function slugify($str) {
    return preg_replace('/[^a-z0-9_]+/i', '', str_replace(' ', '_', trim(strtolower($str))));
}

function shortDate($date) {
    if($date) {
        return date('m/d/Y', strtotime($date)); 
    } else {
        return 'N/A';
    }
}

function longDate($date, $unix = false) {
    if($date) {
        return date('m/d/Y h:i A', $unix ? $date : strtotime($date));
    } else {
        return 'N/A';
    }
}

function fetch_all($stid) {
    $results = array();
    oci_fetch_all($stid, $results, 0, -1, OCI_FETCHSTATEMENT_BY_ROW);
    return $results;
}
////needed to change the IIs setting to basic windows to get the bun

//echo "Auth_USER". $_SERVER['AUTH_USER'];

$bun = explode("\\", $_SERVER['AUTH_USER']);
$bun = trim(strtolower($bun[1]));
$PRODCTION = false;
$use_test_db = true;
$PRODUCTION = $_SERVER['SERVER_NAME'] == 'wtps0369';//esoms production server

if($PRODUCTION || (isset($use_production_db) && $use_production_db)) {
	//esoms production server connections
	$ESOMS_USER = 'POMS_RW';
	$ESOMS_PASS = 'UC4n3d!+';
	$ESOMS_HOST = 'WTP_POMS_P';
		
	$ESOMS_USER_PROD = 'POMS_RW';
	$ESOMS_PASS_PROD = 'UC4n3d!+';
	$ESOMS_HOST_PROD= 'WTP_POMS_P';
		
	$ESOMS_SYNC_USER = 'wtp_esoms_sync';
	$ESOMS_SYNC_PASS = 'eSom5syn!x';
	$ESOMS_SYNC_HOST = 'WTP_POMS_P';
		
	$VISION_USER = 'VISION';
	$VISION_PASS = 'VISION';
	$VISION_HOST = 'WTP_VISION_P';

	$NNDB_USER = 'NNOUN_ADMIN';
	$NNDB_PASS = 'names$%123';
	$NNDB_HOST = 'WTP_NNDB_P';
    
  /* not available on production server
	
		$ESOMS_U_USER = 'SOMSDBA';
		$ESOMS_U_PASS = 'sql';
		$ESOMS_U_HOST = 'WTP_POMS_U';
	
		$ESOMS_U_SYNC_USER = 'wtp_esoms_sync';
		$ESOMS_U_SYNC_PASS = 'eSom5syn!x';
		$ESOMS_U_SYNC_HOST = 'WTP_POMS_U';
	
	 $ESOMS_TR_USER = 'somsdba';
	$ESOMS_TR_PASS = 'sql';
	$ESOMS_TR_HOST = 'WTP_POMS_TR';
	*/
		// TEST
		
		
} else IF (isset($use_test_db) && $use_test_db) {
	//note i get data from production to use in testing sync
		
	//esoms production server connections
	$ESOMS_USER = 'POMS_RW';
	$ESOMS_PASS = 'UC4n3d!+';
	$ESOMS_HOST = 'WTP_POMS_P';
		
	$ESOMS_USER_PROD = 'POMS_RW';
	$ESOMS_PASS_PROD = 'UC4n3d!+';
	$ESOMS_HOST_PROD= 'WTP_POMS_P';
		
	$ESOMS_SYNC_USER = 'wtp_esoms_sync';
	$ESOMS_SYNC_PASS = 'eSom5syn!x';
	$ESOMS_SYNC_HOST = 'WTP_POMS_P';
	
	//esoms TR server connections
	
	$ESOMS_TR_USER = 'somsdba';
	$ESOMS_TR_PASS = 'sql';
	$ESOMS_TR_HOST = 'WTP_POMS_TR';
		
	$ESOMS_TR_SYNC_USER = 'wtp_esoms_sync';
	$ESOMS_TR_SYNC_PASS = 'eSom5syn!x';
	$ESOMS_TR_SYNC_HOST = 'WTP_POMS_TR';
	//esoms T Server Connections 359
	
	$ESOMS_T_USER = 'SOMSDBA';
	$ESOMS_T_PASS = 'NewPassword';
	$ESOMS_T_HOST = 'WTP_POMS_T';//359
	
	$ESOMS_T_SYNC_USER = 'wtp_esoms_sync';
	$ESOMS_T_SYNC_PASS = 'eSom5syn!x';
	$ESOMS_T_SYNC_HOST = 'WTP_POMS_T';
	
	

	//production VISION
	$VISION_USER = 'VISION_WTP_RO';
	$VISION_PASS = 'V1s10nR0978';
	$VISION_HOST = 'WTP_VISION_P';
	//Production NNDB
	$NNDB_USER = 'NNOUN_ADMIN';
	$NNDB_PASS = 'names$%123';
	$NNDB_HOST = 'WTP_NNDB_P';
		
		
} else {
	
		
	/*
    $VISION_USER = 'VISION_WTP_RO'; 
    $VISION_PASS = 'visionwtpro123';
    $VISION_HOST = 'WTP_VISION_T';

    $NNDB_USER = 'NNOUN_RO';// TO DO CHANGE TO READ ONLY USER
    $NNDB_PASS = 'names$%123';
    $NNDB_HOST = 'WTP_NNDB_P';
    //
    $ESOMS_USER = 'SOMSDBA';
		$ESOMS_PASS = 'sql';
		$ESOMS_HOST = 'WTP_POMS_TR';
	//
		$ESOMS_SYNC_USER = 'wtp_esoms_sync';
		$ESOMS_SYNC_PASS = 'eSom5syn!x';
		$ESOMS_SYNC_HOST = 'WTP_POMS_P';
		
		$ESOMS_U_USER = 'SOMSDBA';
		$ESOMS_U_PASS = 'sql';
		$ESOMS_U_HOST = 'WTP_POMS_T';
	
	$ESOMS_U_SYNC_USER = 'wtp_esoms_sync';
	$ESOMS_U_SYNC_PASS = 'eSom5syn!x';
	$ESOMS_U_SYNC_HOST = 'WTP_POMS_T';
	
	 $ESOMS_TR_USER = 'somsdba';
	$ESOMS_TR_PASS = 'sql';
	$ESOMS_TR_HOST = 'WTP_POMS_TR';
	*/
}

?>