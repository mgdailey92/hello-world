<?php
/*
Purpose: demo of script to add simulator log entries
Created 2/2023 James Clegg


*/
$DEFAULT_SERVER = 'TR';//TR, T_0359
session_start();
if(isset($_SESSION["which_server"] )){
	//echo('session already started');
} else {
	//echo ('$_SESSION not set yet');
	$_SESSION["which_server"] = $DEFAULT_SERVER;
}
//load classes used by both initial and post

require_once('helpers/eSOMSdbClass.php');// database connector
include_once('helpers/fyi.php');//debug ulitily
include_once('helpers/security.php'); //security related functions
//fyi($_SESSION["which_server"]);
//main
if ($_SERVER["REQUEST_METHOD"] == "POST"){
	processPost();

} else {
	initialLoad();
	
}
exit;
// end of main
//------------------------------------------------------------------------------------------------
function initialLoad(){
	//fyi('initialLoad');
	
	//get data
	//echo($_SESSION["which_server"]);
	
	$db = getDB($_SESSION["which_server"]);// header set in this routine
	//var_dump($db);
	$entry_list = getEntryList($db);
	// display page
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<i><a href = "#instructions">Instructions</a> are at the bottom of this page.</i>
		<h2>Add entries to the operations log</h2>
		<p>Choose Group(s) and date of entries to add to the log:</p>
		
		<?php
		foreach ($entry_list as $value){
			print '<input type="checkbox" id = "'.$value.'" name = "checklist[]" value = "'.$value.'">';
			print '<label for "'.$value.'"> '.$value.'</lable></br>';
		}
		?>
		<?php
		//get yesterday for default date in calendar
		$now = new DateTime('now');
		date_sub($now, date_interval_create_from_date_string("1 days"));
		//echo date_format($now,"Y-m-d");
		?>
		<lable for="logdate">Date for entries:</lable>
		<input type="date" id ="logdate" name = "logdate" value = "<?php print date_format($now,"Y-m-d"); ?>"> <i>The log must be open for making entries on the date selected</i>
		<br>
		<br>
		<button id="submit" name = "submit" type="submit"  value = "submit"title="This allows you to enter a bunch of standard entries into a log to setup the situation you are enacting in the simulator" >Create Entries</button>
		<hr>
		<h3>Delete Entries in the Operations Log After</h3>
		<lable for="delete_sim_date">Date of first entry:</lable>
		<input type="date" id ="delete_sim_date" name = "delete_sim_date" value = "<?php print date_format($now,"Y-m-d"); ?>"><br><br>
		<button id="delete_sim" name = "delete_sim" type="submit"  value = "delete_sim"title="This deletes the last batch of entries added" >Delete simulator log entries
		</button><br><br>
		<hr>
		<h2>Qualify People</h2><p> in LAWCR-CRS, LAWCR-LAB, LAWCR-MLT, LAWCR-PRO, LAWCR-UTL qualifications</p>
		<br>
		<button id="qualify_users" name = "qualify_users" type="submit"  value = "qualify_users"title="This allows you to select people to make qualified to man a watch stand" >Qualify People  
		</button><br>
		<br>
		<hr>
		<h2>Watchbill Staffing Requirements</h2>
		<button id="station_not_required" name = "station_not_required" type="submit"  value = "station_not_required"title="Make staffing of all watchstands optional" >Remove Watchbill Staffing Requirements  
		</button> &nbsp;
		<button id="station_required_start" name = "station_required_start" type="submit"  value = "station_required_start"title="undo make all stations not required" >Reinstate Watchbill Staffing Requirements  
		</button><br>
		<br>
		<hr>
		<div class="buttons">
			<label for="which_server" title="which_server">Which server:</label>
			<select  id="which_server" name="which_server" title="which_server" >
				<option value = "T_0359"  <?=$_SESSION["which_server"]  == 'T_0359' ?  ' selected="selected"' : '';?> >Testing database T_0359</option>
				<option value = "TR" <?=$_SESSION["which_server"]  == 'TR' ? ' selected="selected"' : '';?>>Simulator TR</option> 
			</select>
			<button id="change_server" name = "change_server" type="submit"  value = "change_server"title="This changes which server" >Change Server 
			</button><br><br>
			
			<button id="test_all" name = "test_all" type="submit"  value = "test_all"title="this runs all the self tests for the page" >Run All Tests
			</button><br>
			
		</div>
		<?php  instructions(); ?>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}

// ---------------------------------------------------------------------
function processPost(){
	//echo 'processPost save to file note nothing can be output before the headers';
	securityDoubleSubmitCheck();//security Double submit check
	//fyi($_POST);
	$optional = array();
	$optional = array('test_all','submit','reset','delete_sim','logdate','delete_sim_date','create_confirm','delete_confirm','cancel','change_server','Confirm_serverChange','qualify_users','submit_users','undo_users_qual','station_not_required','station_confirm','station_required','station_required_start');//white list of expected variables in $_post
	$required = array('which_server');//white list of required variables in $_post
	$optional_arrays = array();
	$optional_arrays[] = 'checklist';
	$optional_arrays[] = 'users';
	$post_data = validateFields($required,$optional,$optional_arrays);//security
	//check payload
	if(isset($_POST['payload1']) === true){
		$valid_payload = validatePayload($_POST['payload1'],$_POST['checksum1']);
		if ($valid_payload === true){
				//fyi('payload valid');
				$payload = extractPayload($_POST['payload1']);
		} else {
				fyi('Payload corupt');
				die('die');
		}
	} else {
		// no payload
	}
	//set the server vairables
		//fyi('post which server'.$post_data['which_server']);
		//fyi('session which server'.$_SESSION['which_server'] );
	$_SESSION['which_server'] = $post_data['which_server'];
	$which_server = $post_data['which_server'];
	//data validated did it pass validation
	if($post_data['valid'] == false) {
		print $post_data['error'];
		fyi($_POST);
		exit;
	} else {
		//data is valid
			//fyi('post data','v');
			//fyi($post_data);
		$db = getDB($which_server);
		//which button was pushed
		if(isset($post_data['test_all']) === true){
				runTests($db,$post_data);
		} elseif ( isset($post_data['submit']) === true){
				//fyi('submit add long entries ');
				add_log_entries($db,$post_data);
		} elseif (isset($post_data['create_confirm']) === true){
				//fyi('create confirm');
				add_entries_confirmed($db,$payload);
		} elseif ( isset($post_data['delete_sim']) === true){
				//fyi('delete_sim goes here');
				deleteSimStart($db,$post_data);
		} elseif (isset($post_data['delete_confirm']) === true){
				//fyi('cdelete_confirm');
				deleteSimConfirm($db,$payload);
		} elseif (isset($post_data['cancel']) ===true){
				//fyi('cancel');
				header("Refresh:0");
		} elseif (isset($post_data['change_server']) === true){
				//fyi('Change Server To');
				changeServer($db,$post_data['which_server']);
		} elseif (isset($post_data['Confirm_serverChange'])== true ){
				header("Refresh:0");
		} elseif (isset($post_data['qualify_users']) === true ){
				//fyi('qualify_users start ');
				showPossibleUsers($db);
		} elseif (isset($post_data['submit_users']) === true ) {
				//fyi('submit users');
				QualifyPeople($db,$post_data);
		} elseif (isset($post_data['undo_users_qual']) === true ) {
				undoQualifyPeople($db,$payload);
		} elseif (isset($post_data['station_not_required']) === true) {
				stationsOptionalStart($db);
		} elseif (isset($post_data['station_confirm']) === true ){
				stationOptionalConfirm($db,$post_data);
		} elseif (isset($post_data['station_required_start']) === true){
				StationRequiredStart();
		} elseif (isset($post_data['station_required_confirm']) === true) {
				StationResults($db);
		
		} elseif (isset($post_data['station_required']) === true) {
				stationRequiredConfirm($db);
		} else {
				$error = 'processPost<br>';
				$error = $error.'unknown button<br>';
				$error = $error.serialize($post_data);
				error_page($error);
		}
	}
}


//display list of log entries selected and show add them button
function add_log_entries($db,$post_data){
	//fyi('add_log_entries start');
	//fyi($post_data);
	//page header output in getDB function
	if (isset($post_data['checklist']) === false ){
		print '<h2>No entries selected</h2>';
		?>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
			<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
			<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $post_data['which_server']?>" />
			<div class="buttons">
				<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
				</button>
			</div>
			<br>
		</form>
		<?php
		$footer_include ="<hr>";
		footer();
	} else  {
		//Something checked proceed
		// create payload
		$payload = array();
		$payload = prepPayload($post_data);
		//fyi('payload:'.$payload);
		$results = getStandardEntries($db,$post_data['checklist']);
		print '<h2> Add the following entries? </h2>';
		print 'Date for new entries: '. $post_data['logdate'].'</br>';
		displayHeaderRow();
		foreach ($results as $row){
			displayOneRow($row);
		}
		displayEndOfTable();
		?>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
			<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
			<input type = "hidden" name = 'payload1' id = 'payload1' value = '<?php print $payload['payload'];?>' />
			<input type = "hidden" name = 'checksum1' id = 'checksum1' value = '<?php print $payload['checksum'];?>' />
			<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $post_data['which_server']?>" />
		</br>
		<div class="buttons">
		<button id="create_confirm" name = "create_confirm" type="submit"  value = "create_confirm"title="This confirms the creation of the logs" class="default" >Confirm
			</button> 
			<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
			</button>
			</div>
			<br>
		</form>
		<?php
		$footer_include ="<hr>";
		footer();
	}
}

// add entries they already confirmed
function add_entries_confirmed($db,$payload){
	//fyi('start add entries confirmed');
	$queries = array();
	//get the entries to insert from the payload
	//fyi($payload);
	$results = getStandardEntries($db,$payload['checklist']);
	//fyi($results);
	$counter = 0;
	foreach ($results as $row){
		$counter ++;
		$params = ConvertToParams($db,$row,$payload['logdate']);
		$sql = insertlogString();
		//fyi($sql);
		$results = $db->sql($sql,$params);//push to db
		//var_dump($results);
	}
	//page header output in getDB function
	print '<h1> Added '.$counter.' log entries </h1>'; 
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION["which_server"]?>" />
		<div class="buttons">
		<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
		</button>
		</div>
		<br>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}
function getStandardEntries($db,$checklist){
	//fyi(getStandarEntries);
	$count = count($checklist);
	// fyi('count:'.$count);
	//build where clause
	$where_part = "(";
	$counter = 0;
	$params = array();
	$base = ':list';
	$or_part = '';
	if(0 == $count){
		nothingSelected();
	} else {
		foreach($checklist as  $entry){
			$the_index  = $base.$counter;
			$params[$the_index] = $entry.'%';
			$where_part = $where_part.$or_part.' sel.entry_description like '.$the_index;
			if(0 ==$counter){
				$or_part = ' OR ';
			} else {
					//no change
			}
			$counter = $counter +1;
		}
		$where_part = $where_part.')';
		//fyi($where_part);
		$sql = "SELECT sel.*, nvl(k.keyword,'23:59') keyword  FROM somsdba.standard_entry_list sel LEFT JOIN somsdba.standard_keyword_list k ON k.site_code = sel.site_code AND k.entry_description = sel.entry_description AND k.entry_type_code  = sel.entry_type_code WHERE sel.entry_type_code like '%AAA SIM   %' and ".$where_part. ' ORDER BY  k.keyword asc';
		//fyi($sql);
		//fyi($params);
		$results = $db->sql($sql,$params);
		//var_dump($results);
		return $results;
	} 
}

//sql for insert function used only in add_entries_confirmed
function insertlogString(){
	$sql = "INSERT INTO somsdba.LOG_ENTRIES  (SITE_CODE, LOG_ID, SHIFT_ID,
	SHIFT_DATE,ENTRY_TIMESTAMP,ANNOTATION_NUMBER,ENTRY_TYPE_CODE,USER_ID,ENTRY_TEXT,
	ENTRY_TIME,OPERATOR_POSITION_DESCR,IS_OPEN,IS_STANDING_ORDER,
	IS_MAINTENANCE_RULE_RELATED,STANDARD_ENTRY_DESCRIPTION,UNIT_ID,ANNOTATION_TIMESTAMP,
	ANNOTATION_SITE_CODE,ANNOTATION_LOG_ID) Values (
	:site_code,:log_id,:shift_id,
	to_date(:shift_date,'YYYY-MM-DD'),
	to_date(:entry_timestamp,'YYYY-MM-DD-HH24:MI'),
	:annotation_number,:entry_type_code,:user_id, :entry_text, 
	to_date(:entry_time,'YYYY-MM-DD-HH24:MI'),
	:operator_position_descr,:is_open,:is_standing_order,:is_maintenance_rule_related,
	:standard_entry_description,:unit_id,
	to_date(:annotation_timestamp,'YYYY-MM-DD-HH24:MI'),
	:annotation_site_code,:annotation_log_id)";
	return $sql;
}

//params for insert function used only in add_entries_confirmed
function ConvertToParams($db,$row,$logdate){
	//fyi('ConvertToParams');
	$active_log = getActiveCurrentLogInfo($db);
	$t = $logdate.'-'.$row['KEYWORD'];
	$params = array();
	$params[':site_code'] = str_pad('1',6,' ');
	$params[':log_id'] = 1;
	$params[':shift_id'] = $active_log['SHIFT_ID'];//current and active
	$params[':shift_date'] = $active_log['SHIFT_DATE'];
	$params[':entry_timestamp'] = $t;
	$params[':annotation_number'] = 0;
	$params[':entry_type_code'] = str_pad('AAA SIM',10);
	$params[':user_id'] = str_pad('TEST1',12);
	$params[':entry_text'] = $row['ENTRY_TEMPLATE'];
	//fyi($row['ENTRY_TEMPLATE'],'g');
	$params[':entry_time'] = $t;
	$params[':operator_position_descr'] = str_pad('SIMULATION',25);
	$params[':is_open'] = 0;
	$params[':is_standing_order'] = 0;
	//$params[':is_rolled_forward'] = 0;
	$params[':is_maintenance_rule_related'] = 0;
	$params[':standard_entry_description'] = $row['ENTRY_DESCRIPTION'];
	$params[':unit_id'] = $row['UNIT_ID'];
	//$params[':is_automatic_log_entry'] = 
	$params[':annotation_timestamp'] = $t;
	//$params[':share_link_id'] = 
	$params[':annotation_site_code'] = str_pad('1',6,' ');
	$params[':annotation_log_id'] = 1;
	//$params[':originating_key'] = 
	//fyi('params:');
	//fyi($params);
	return $params;
}

function nothingSelected(){
	fyi('nothing selected');
}


function deleteSimStart($db,$post_data){
	//fyi('delete entries');
	//fyi($post_data);
	//show stuff to be deleted
	$payload = array();
	$active_log_info = getActiveCurrentLogInfo($db);
	$post_data['active_shift_date'] = $active_log_info['SHIFT_DATE'];
	$post_date['active_shift_id'] =$active_log_info['SHIFT_ID'];
	$payload = prepPayload($post_data);
	//fyi('payload:'.$payload);
	//fyi($post_data['logdate']);
	$results = getSimulatorEntriesToUndo($db,$post_data['delete_sim_date'],$active_log_info['SHIFT_DATE']);
	//fyi($results);
	print '<h1><b>Delete</b> entries after : '. $post_data['delete_sim_date'].'</h1>';
	print '<p>The following log entries will be deleted</p>';
	displayEntryHeaderRow();
	foreach ($results as $row){
		displayOneEntryRow($row);
	}
	displayEndOfTable();
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = 'payload1' id = 'payload1' value = '<?php print $payload['payload'];?>' />
		<input type = "hidden" name = 'checksum1' id = 'checksum1' value = '<?php print $payload['checksum'];?>' />
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $post_data['which_server']?>" />
		</br>
		<div class="buttons">
		<button id="delete_confirm" name = "delete_confirm" type="submit"  value = "delete_confirm"title="This confirms the deletion of the logs entries"  >Confirm Delete
		</button> 
		<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" class="default" >Return to Add Entries
		</button>
		</div>
		<br>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}

function deleteSimConfirm($db,$payload){
	//fyi('deleteSimConfirm');
	//fyi($payload);
	print 'Entries after '.$payload['delete_sim_date'].' and of type <b>AAA SIM</b> Deleted on log date '. $payload['active_shift_date'].' </br>';
	$result = deleteSimulatorEntries($db,$payload['delete_sim_date'],$payload['active_shift_date']);
	//fyi($result);
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION["which_server"] ?>" />
		<div class="buttons">
		<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
		</button>
		</div>
		<br>
	</form>
	<?php
}

function changeServer($db,$which_server){
	//fyi($which_server);
	//$db = getDB($which_server);
	$server_name = 'unknown';
	$_SESSION['which_server'] = $which_server;
	if ( $which_server ==="TR") {
		$server_name = 'Simulator TR';
	} else if ($which_server === "T_0359") {
		$server_name = 'Testing Database 0359 T';
	} else {
		$server_name = 'unknown';
	}
	print '<h1> Changing Server to '.$server_name.'</h1>';
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION["which_server"] ?>" />
		<div class="buttons">
		<button id="Confirm_serverChange" name = "Confirm_serverChange" type="submit"  value = "Confirm_serverChange"title="Confirm_serverChange" >Confirm Change of Server
		</button>
		</div>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
	//show delete button
}
//USERS -------------------------------------Users ----------------------------------------
function showPossibleUsers($db){
	$people_list = getEBASICusers($db);
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION["which_server"]?>" />
		<h1>Check the people you to make qualified for all posistions</h1>
		<?php
			foreach ($people_list as $value){
				print '<input type="checkbox" id = "'.$value['USER_ID'].'" name = "users[]" value = "'.$value['USER_ID'].'">';
				print '<label for "'.$value['NAME'].'"> '.$value['NAME'].' <i>'.$value['TITLE'].'</i></lable></br>';
			}
			?>
			<div class="buttons">
				<br>
				<button id="submit_users" name = "submit_users" type="submit_users"  value = "submit_users"title="Submit Users" class="default">Submit Users</button>	
				<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
				</button><br>
				<br>
			</div>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}

function QualifyPeople($db,$post_data){
	$undo_list = array();
	$qual_list = "'LAWCR-CRS','LAWCR-LAB','LAWCR-MLT','LAWCR-PRO','LAWCR-UTL'";
	$qual_name_list = "'LAWCR-CRS', 'LAWCR-LAB', 'LAWCR-MLT', 'LAWCR-PRO', 'LAWCR-UTL'";
	$payload_parts = array();
	if(isset($post_data['users']) === false ){
		print '<h2>No People selected</h2>';
		?>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
			<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
			<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $post_data['which_server']?>" />
			<div class="buttons">
				<button id="qualify_users" name = "qualify_users" type="submit"  value = "qualify_users"title="This allows you to select people to make qualified" class="default">People Qualified  
				</button> <button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
				</button>
			</div>
			<br>
		</form>
		<?php
		$footer_include ="<hr>";
		footer();
	} else {
		//users selected
		//add the rows
		//fyi($post_data);
		//fyi($post_data['users']);
		//create in clause
		$user_ids = '';
		
		$user_ids = implode("','",$post_data['users']);
		// sql merge into query
		$user_names = getUserNamesFromIDs($db, $user_ids,);
		$results = getQualsToAdd($db,$user_ids,$qual_list);
		if(count($results) == 0){
			//fyi('no quals to add for '.$user_ids);
		} else {
			//need to add quals
			$payload_parts['add_users_qual'] = $results;
			//add quals
			foreach ($results as $row){
				//fyi('adding '.$row['USER_ID'].' '.$row['QUALIFICATION_ID']);
				//fyi ('adding '.$row['QUALIFICATION_ID'].' to '.$user_names[trim($row['USER_ID'])].' '.trim($row['USER_ID']));
				try {
				$sql = "insert into somsdba.watchbill_user_qualifications (site_code, qualification_id, user_id, display_as_qualified) values (:site_code,:qual_id, :user_id,1)";
				//fyi($sql);
				$params = array();
				$params[':site_code'] = str_pad('1',6,' ',STR_PAD_RIGHT);
				$params[':qual_id'] = str_pad($row['QUALIFICATION_ID'],12,' ',STR_PAD_RIGHT);
				$params[':user_id'] = str_pad($row['USER_ID'],12,' ',STR_PAD_RIGHT);
				$results = $db->sql($sql,$params);
				//fyi('did the insert work? ');
				//var_dump($results);
				} catch( Exception $e) {
					echo 'Caught exception: ',  $e->getMessage(), "\n";
				}
				//fyi('inserted one');
			}
		}
		//fyi('update quals for people in list that have display as qualified = 0');
		foreach ($post_data['users'] as $user){
			$sql = "select * from somsdba.watchbill_user_qualifications where display_as_qualified = 0 and trim(user_id) = :user_id and trim(qualification_id) in (".$qual_list.") order by user_id";
			$params = array(':user_id'=> $user);
			try {
				$results = $db->sql($sql,$params);
			} catch (Exception $e) {
					echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
			//fyi($results);
			//update as needed
			if(isset($results[0]['SITE_CODE']) === false ){
				//fyi('no display_as_qualified to set to 1 or add to unto_list');
			} else {
				$prev_user = '';
				foreach ($results as $row){
					//fyi('add to undo list');
					//fyi($row);
					$undo_list[] = $row;
					if ($prev_user == $row['USER_ID']){
						//fyi('skipping row user already in ');
					} else {
						$sql = "UPDATE somsdba.watchbill_user_qualifications SET display_as_qualified = 1 WHERE display_as_qualified = 0 AND trim(user_id) = :user_id AND trim(qualification_id) IN (".$qual_list.")";
						//fyi($sql.' _ '.$user);
						$params = array(':user_id'=> trim($row['USER_ID']));
						try {
							$results2 = $db->sql($sql,$params);
							//fyi($results2);
						} catch (Exception $e) {
							echo 'Caught exception: ',  $e->getMessage(), "\n";
						}
					}
					$prev_user = $row['USER_ID'];
				}
				//fyi('undo_list:');
				//fyi($undo_list);
				$payload_parts['undo_update'] = $undo_list;
			} 
		}
		//prep payload
		
		$payload = prepPayload($payload_parts);
		?>
		<h2><?php 
		foreach ($user_names as $value){
			print ' '.$value.'<br>';
		}
		if (Count($user_names) == 1) {
			print 'is';
		} else {
			print 'are';
		}
		?>  now qualified in <?php print $qual_name_list; ?></h2>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
			<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
			<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $post_data['which_server']?>" />
			<input type = "hidden" name = 'payload1' id = 'payload1' value = '<?php print $payload['payload'];?>' />
			<input type = "hidden" name = 'checksum1' id = 'checksum1' value = '<?php 	print $payload['checksum'];?>' />
			<div class="buttons">
				<button id="undo_users_qual" name = "undo_users_qual" type="submit"  value = "undo_users_qual"title="This allows you to undo the user quals added by add Qualify People">Undo add quals
				</button><br><br>
				<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
				</button>
			</div>
			<br>
		</form>
		<?php
		$footer_include ="<hr>";
		footer();		
	}
}
function undoQualifyPeople($db,$payload){
	//fyi('undoQualifyPeople');
	//fyi($payload);
	$delete_counter = 0;
	$update_counter = 0;
	if(isset($payload['add_users_qual']) === true ){
		foreach($payload['add_users_qual'] as $row){
			//fyi('delete');
			//fyi($row);
			$delete_counter = $delete_counter +1;
			$sql = "DELETE from somsdba.watchbill_user_qualifications WHERE trim(qualification_id) = trim(:qual_id) AND TRIM(USER_ID) = TRIM(:user_id)";
			$params = array(':qual_id'=>$row['QUALIFICATION_ID'], ':user_id'=>$row['USER_ID']);
			try {
				//fyi($sql);
				//fyi($params);
				$results = $db->sql($sql,$params);
			} catch (Exception $e) {
					echo 'Caught exception: ',  $e->getMessage(), "\n";
					die('die');
			}
		}
	} else {
		//fyi('no quals added to be undone');
	}
	//fyi('undo updates');
	if(isset($payload['undo_update']) === true ) {
		foreach($payload['undo_update'] as $row){
			//fyi('undo update');
			//fyi($row);
			$update_counter = $update_counter +1;
			$sql = "UPDATE somsdba.watchbill_user_qualifications Set display_as_qualified = 0 WHERE  display_as_qualified = 1 and trim(user_id) = trim(:user_id) and trim(qualification_id) = trim(:qual_id)";
			$params = array(':user_id'=>$row['USER_ID'],':qual_id'=>$row['QUALIFICATION_ID']);
			try {
				$results = $db->sql($sql,$params);
			} catch (Exception $e) {
					echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
		}
	} else {
		//fyi('no updates to undo');
	}
	//fyi('OUTPUT RESULTS');
	?>
	<h1>Undo Add Qualified People</h1>
	<h2><?php print $delete_counter; ?> new quals deleted.  <?php print $update_counter; ?> updates undone</h2>
	<p><i>Only the last add can be undone.</i></p>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
			<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
			<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION['which_server']?>" />
			<div class="buttons">
				<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
				</button>
			</div>
			<br>
		</form>
		<?php
		$footer_include ="<hr>";
		footer();		
	
}
//-------------------------------------------watch bill -----------------
function stationsOptionalStart($db){
	//fyi('stationStart start');
	$active_log = getActiveCurrentLogInfo($db);
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION['which_server']?>" />
		<h2>Remove Watchstation Staffing Requirement sin operations log for '<?php print $active_log['SHIFT_DATE'] ?>'</h2>
		<div class="buttons">
		<button id="station_confirm" name = "station_confirm" type="submit"  value = "station_confirm"title="This confirms the making all the watch stations not required" class="default" >Confirm
		</button> 
		<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
		</button>
		<br>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}
function stationOptionalConfirm($db){
	//fyi('Station Confirm');
	makeAllStationsNotRequired($db);
	$active_log = getActiveCurrentLogInfo($db);
	print '<h1>Watchbill Staffing is Not Required in operations log for '.$active_log['SHIFT_DATE'].'</h1>'; 
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION["which_server"]?>" />
		
		<div class="buttons">
		<button id="station_required_start" name = "station_required_start" type="submit"  value = "station_required_start"title="undo make all stations not required" >Reinstate Watchbill Staffing Requirments  
		</button><br>
		<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
		</button>
		</div>
		<br>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}
function StationRequiredStart(){
	//fyi('stationStart start');
	
	print '<h1>Reinstate Watchbill Staffing Requirements in operations log</h1>'; 
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION['which_server']?>" />
		
		<div class="buttons">
		<button id="station_required" name = "station_required" type="submit"  value = "station_required"title="This confirms the making all the watch stations not required" class="default" >Confirm
		</button> 
		<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
		</button>
		<br>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}
function stationRequiredConfirm($db){
	//fyi('stationRequiredConfirm');
	undoMakeAllStationsNotRequired($db);
	$active_log = getActiveCurrentLogInfo($db);
	print '<h1>Watchbill Staffing Requirements Are Reinstated in operations log for '.$active_log['SHIFT_DATE'].'</h1>'; 
	?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
		<?php SecurityDoubleSubmitToken() ?> <!--needed in all forms -->
		<input type = "hidden" name = "which_server" id = "which_server" value = "<?php print $_SESSION["which_server"]?>" />
		<div class="buttons">
		
		<button id="cancel" name = "cancel" type="submit"  value = "cancel"title="cancel" >Return to Add Entries
		</button>
		</div>
		<br>
	</form>
	<?php
	$footer_include ="<hr>";
	footer();
}

function makeAllStationsNotRequired($db){
	$params = array();
	$active_log = getActiveCurrentLogInfo($db);
	$params[':shift_date'] = $active_log['SHIFT_DATE'];
//	$sql = "update somsdba.standard_shift_staffing set is_required = 0 where  site_code='1     ' AND log_id = 1 ";
//fyi($params);
	$sql = "update somsdba.shift_staffing set 
		SHIFT_POSITION_REQUIRED = 0 
		WHERE site_code = '1' 
		and log_id = 1 
		and shift_date = to_date(:shift_date,'YYYY-MM-DD')"; 
	try {
		//fyi($sql);
		$results = $db->sql($sql,$params);
		//fyi($results);
	} catch (Exception $e) {
			echo 'Caught exception: ',  $e->getMessage(), "\n";
	}
	
}

function undoMakeAllStationsNotRequired($db){
	$params = array();
	$active_log = getActiveCurrentLogInfo($db);
	$params[':shift_date'] = $active_log['SHIFT_DATE'];
	$sql = "update somsdba.shift_staffing set 
		SHIFT_POSITION_REQUIRED = 1 
		WHERE site_code ='1'
		AND log_id = 1
		AND shift_Position_no  in (1,2,3,4,5,8,9,10,11,12,13,14,15,16,18,19,20,21,22)
		AND shift_date = to_date(:shift_date, 'YYYY-MM-DD')";//  <--this may need changed if more stations become required by default
	
	try {
		//fyi($sql);
		$results = $db->sql($sql,$params);
	} catch (Exception $e) {
		echo 'Caught exception: ',  $e->getMessage(), "\n";
	}
}

//helpers -------------------------------------------------------------------------------
//ui helpers
function footer(){
	print "<br>";
	print "<br>";
	print "<hr>";
	print " </div><!-- end of main-->";
	print("</body>");
	print ("</html>");
}
function displayHeaderRow(){
	Print '<table>';
	print '<tr>';
	Print '<th>Time</th><th>Entery</th><th>Entry Description</th>';
}
function displayOneRow($row){
	print '<tr>';
	print '<td>'.$row['KEYWORD'].'</td><td>'.$row['ENTRY_TEMPLATE'].'</td><td>'.$row['ENTRY_DESCRIPTION'].'</TD>';
}
function displayEndOfTable(){
	print '</table>';
}
function displayEntryHeaderRow(){
	Print '<table>';
	print '<tr>';
	Print '<th>Shift Date</th><th>Entry Timestamp</th><th>Entry Text</th>';
}
function displayOneEntryRow($row){
	print '<tr>';
	print '<td>'.$row['SHIFT_DATE'].'</td><td>'.$row['ENTRY_TIMESTAMP'].'</td><td>'.$row['ENTRY_TEXT'].'</TD>';
}


	//ui db helpers ----------------------------------------------------
function getEntryList($db){
	$out = array();
	$sql = "select distinct substr(entry_description,0,instr(entry_description,' ',1,2)-1 ) the_list from somsdba.standard_entry_list where entry_type_code = :entry_type_code order by the_list";
	$params = array(':entry_type_code'=>'AAA SIM   ');
	// note to self with paras of site_code you have to have trailing spaces on Char Columns for it to work.
	$results = $db->sql($sql,$params);
	//fyi($results);
	foreach ($results as $row){
		$out[] = $row['THE_LIST'];
	}
	//fyi($out);
	return $out;
}

function getActiveCurrentLogInfo($db, $log_id = 1){
	$out = array();
	$sql = "select * from somsdba.current_log_list where log_id = :log_id";
	$params = array(':log_id'=>$log_id);
	$results = $db->sql($sql,$params);
	$row = $results[0];
	//var_dump($row['SHIFT_DATE']);
	$shift_date = DateTimeImmutable::createFromFormat('j-M-y',$row['SHIFT_DATE'])->format('Y-m-d');
	//fyi($shift_date);
	$out['SHIFT_DATE'] = $shift_date;
	$out['SHIFT_ID'] = $row['SHIFT_ID'];
	return $out;
}

function getSimulatorEntriesToUndo($db,$shift_date,$active_shift_date){	
	//fyi($shift_date);
	//fyi($active_shift_date);
	$sql = "SELECT * FROM somsdba.log_entries WHERE log_id = 1
	AND entry_type_code like 'AAA SIM%'
	AND entry_timestamp >= to_date(:shift_date,'YYYY-MM-DD')
	AND Shift_date = to_date(:active_shift_date,'YYYY-MM-DD')";
	$params = array(':shift_date'=>$shift_date,':active_shift_date'=>$active_shift_date);
	//fyi($params);
	$results = $db->sql($sql,$params);
	//fyi($results);
	return $results;
}

function deleteSimulatorEntries($db,$shift_date,$active_shift_date){
	$sql = "DELETE from somsdba.log_entries  WHERE log_id = 1
	AND entry_type_code like 'AAA SIM%'
	AND entry_timestamp >= to_date(:shift_date,'YYYY-MM-DD')
	AND Shift_date = to_date(:active_shift_date,'YYYY-MM-DD')";
	$params = array(':shift_date'=>$shift_date,':active_shift_date'=>$active_shift_date);
	try {
	$results = $db->sql($sql,$params);
	} catch (Exception $e) {
		echo 'Caught exception: ',  $e->getMessage(), "\n";
	}
	//fyi($results);
	return $results;
}
//-- user related helpers -----------------------------------------------------
function getEBASICusers($db){
	$sql ="select distinct trim(ug.user_id) user_id, u.name, u.title from somsdba.user_group_users ug
	JOIN somsdba.userlog u on u.user_id = ug.user_id  and u.user_status = 1
	where user_group_id like 'EBASIC%' order by name";
	$params = array();
	$results = $db->sql($sql,$params);
	//fyi($results);
	return $results;
}
function getUserNamesFromIDs($db,$user_ids){
	$out = array();
	$sql ="select distinct trim(ug.user_id) user_id, u.name, u.title from somsdba.user_group_users ug
	JOIN somsdba.userlog u on u.user_id = ug.user_id  and u.user_status = 1
	where trim(ug.user_id) in (:user_ids)  order by name";
	$params = array(':user_ids' => $user_ids);
	$results = $db->sql($sql,$params);
	//fyi($results);
	//turn into indexed array
	foreach ($results as $row){
		$out[$row['USER_ID']] = $row['NAME'];
	}
	return $out;
}

function getQualsToAdd($db,$user_ids,$qual_list){
	//fyi($user_ids);
	$sql = "select '1     ' SITE_CODE, q.qualification_id,  u.user_id from somsdba.user_group_users u
	full outer join somsdba.watchbill_qualifications q on q.site_code = '1' AND trim(qualification_id) in (".$qual_list.")
	where u.User_group_id  = 'EBASIC' AND trim(U.USER_ID) IN (:user_ids) 
	MINUS
	select site_code, qualification_id, user_id from SOMSDBA.watchbill_user_qualifications WHERE   trim(qualification_id) in (".$qual_list.") AND trim(USER_ID) IN (:user_ids) 
	";
		$params = array(':user_ids' => $user_ids);
	$results = $db->sql($sql,$params);
	//fyi($results);

	return $results;
}
function insertQualRow($db,$row){
  
}

//---------------------------------------------------------other helpers
function getDB($which_server){
	//FYI($which_server);
	include_once('helpers/conn.php');
	require_once('helpers/myPDOdbClass.php');
	require('helpers/headerNoNav.php');
	//echo $which_server;
	
	if($which_server == 'TR'  || $which_server == 'WTP_POMS_TR'){
		$db =new myPDOdb($ESOMS_TR_USER, $ESOMS_TR_PASS,$ESOMS_TR_HOST);
		Print '<h3 class="testing" >Simulator TR </h3>';
		/*} else if ($which_server == 'prod0171'){
			$db =new myPDOdb($ESOMS_USER_PROD , $ESOMS_PASS_PROD,$ESOMS_HOST_PROD);
			Print '<h3 class="production" >Production server </h3>';
		*/
	} else if ($which_server == 'T_0359' or $which_server = 'wtp_poms_t'){
		//echo $which_server;
		//die('should never get here 938');
		$db =new myPDOdb($ESOMS_T_USER, $ESOMS_T_PASS,$ESOMS_T_HOST);
		Print '<h3 class="testing" >Testing Database 0359 T</h3>';
		
		
	} else {
		die('die unknown server'.$which_server);
	}
	return $db;
	
}
// IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIiii instructions IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIiii
function instructions(){
	//fyi('Instructions go here');
	?>
	<hr>
	<h1><a id="instructions">Instructions</a></h1>
	<h3>Creating Standard Entries for the Simulator database</h3>
	
	<p>The week before you need the entries, in <b>production</b> eSOMS, create standard entries.</p>
	<p>
	<ol>
		<li>Got to the eSOMS <span class = "key1">Production</span> Database and Log in. </li>
		<li>Go To <span class="key1">Narrative Logs</span> -> <span class="key1">Log Setup</span>.</li>
		<li>Click on the <span class="key1">Standard Entries</span> tab.</li>
		<li>In the <span class="key1">tree view</span> click on  zz Simulator Entries.</li>
		<li>At the top of the Page Click on the tab <span class="key1">Standard Entry List</span>.</li>
		<li>Click on the new record icon<img src="images/new_doc.jpg" alt="New Icon" width="116" height="26"> in the upper right.</li>
		<li>Create an Entry Description for the new entry. <br>
			The script will identify groups of entries base on the first two words of the Entry Description.  
				For example: to create a group of entries for a fire scenario. all the entries descriptions would start with &quot;fire scenario&quot;:
			<ul>
				<li>fire scenario 01</li>
				<li>fire scenario 02</li>
			</ul>
		</li> 
		<li>Click Save.<img src="images/save.jpg" alt="New Icon" width="116" height="26"></li>
		<li>In the <span class="key1">tree view</span> click on the new entry, created in step 6, under zz Simulator.<img src="images/zzSumulatorEntries.jpg" alt="New Icon" width="116" height="26"></li>
		<li>Complete the following on the Details tab: 
			<ul>
				<li>Facility -- user drop down list (required)</li>
				<li>Entry Text (required)</li>
				<li>Check the box next to the Active Alarm, Open item and Include in All turnover Reports, as applicable</li>
			</ul>
		</li>
		<li>Select <span class="key1">Keywords</span> tab.</li>
		<li>Click on the new document icon<img src="images/new_doc.jpg" alt="New Icon" width="116" height="26"> in the upper right.</li>
		<li>In the <span class="key1">Add keyword pop-up</span>, in the <span class="key1">Enter new keyword</span> field type the time you would like on the entries in the form 15:24 <i>(HH:MM)</i>.</li>
		<li>Click <span class="key1">OK</span>.
		<li>Click Save<img src="images/save.jpg" alt="New Icon" width="116" height="26"></li>
		<li>Repeat steps 6 through 15 to create additional entries.</li>
	</ol>	
	</p>
	<p>	<i>The Simulator database will be refreshed from production every weekend. If you need Standard Entries this week you can enter them in the Simulator instance of eSOMS, but they will be deleted when the database is refreshed the next weekend.</i>
	</p>
	<h3>Create Log Entries from Standard Entries</h3>
	<p>
		<ol>
		<li>On <span class="key1">Simulator Add Logs</span> Page <i>(this page).</i>
		<li>Check one or more boxes for the standard entry groups you would like to add to the operations log.</li>
		<li>Enter the <span class="key1">Date for entries</span>.</li>
		<li>Click   <span class="key1">Create Entries</span> button.
		</ol>
		<p><i>Entries are added to the <b>current</b> and <b>active log</b> with the Entry Time from the <b>Date for entries</b> and <b>keyword</b>.</i></p>
	<h3>Deleting Simulator Log Entries</h3>
	<p><ul>
		<li>In the <span class="key1">Date for Entries:</span> field enter the date of the oldest entry to be deleted.</li>
		<li>Click <span class="key1">Delete simulator log entries</span> button.</li>
		<li>entries to be deleted will be listed.<li>
		<li>Click <span class="key1">Confirm Delete</span> button.</li>
		
	</ul><i>Delete simulator log entries will delete all log entries of the type of <b>AAA SIM</b> and with a date after the <span class="key1">Date for Entries</span>.</i></p>
	<h3>Qualify People</h3>
	<p><ol>
		<li>Click <span class="key1">Qualify People</span>.</li>
		<li>Check one or more check box. </li>
		<li>Click <span class="key1">Submit Users</span>.</li>
		<li>To undo adding quals click <span class="key1">Undo add quals</span>. 
		</li>
	</ol>
	<i>Qualify People will make the people checked appear as qualified in LAWCR-CRS, LAWCR-LAB, LAWCR-MLT, LAWCR-PRO, LAWCR-UTL.</i>
	</p>
	<h3>Watchbill Staffing Requirements</h3>
	<p>To Remove
	<ol>
		<li>Click <span class="key1">Remove Watchbill Staffing Requirements</span>.
		</li>
		<li>Click <span class="key1">Confirm</span>.
		</li>
		
	</ol>
	</p>
	<p>
	To Reinstate 
	<ol>
		<li>Click <span class="key1">Reinstate Watchbill Staffing Requirements</span>.</li>
		<li>Reinstate Watchbill Staffing page will display.</li>
		<li>Click <span class="key1">Confirm</span>.</li>
		</ol>
	</p>
	<h3>Server Change and Testing</h3>
	<p>
		<ol>
			<li>Click <span class="key1">Select Which Server</span>.</li>
			<li>Click <span class="key1">Change Server</span>.</li>
		</ol>
	</p>
	<!--
	<p>
		To run tests
		<ol>
			<li>Click <span class="key1">Run All Tests</span> 
			</li>
		</ol>
	</p>
	-->
	<?php
	$footer_include ="<hr>";
	footer();
}
//tests ---------------------------------------------------------------------------------
function runTests($db){
	
	fyi('runTests');
//	test1($db);
//	test2($db);
//	test3($db);
//	test4($db);
//	test5users($db);
	test6users($db);
	print '<a href="sim_add_logs.php">Reload Simulator Add Logs</a>';
	$footer_include ="<hr>";
	footer();
	
}
function test1($db){
	fyi('test get list of entries for drop down');
	$entry_list = getEntryList($db);
	fyi($entry_list);
}
function test2($db){ // testing for database switching working
	var_dump($db);
}
function test3($db){ 
	fyi('test of get current log');
	$active_log_info = getActiveCurrentLogInfo($db);
	fyi($active_log_info);
	// remove one row from undo stack
}
function test4($db){
	fyi('test4');
	$active_log_info = getActiveCurrentLogInfo($db);
	$results = getSimulatorEntriesToUndo($db,$active_log_info['SHIFT_DATE'],$active_log_info['SHIFT_DATE']);
	fyi($results);
}
function test5users($db){
	fyi('test5users output should be an array of users');
	$results = getEBASICusers($db);
	fyi($results);
}
function test6users($db) {
	fyi('test6users output shoud be array of users');
	$user_ids = array();
	$user_ids[] = 'NMARMSTR';
	$user_ids[] = 'MJALMAGU';
	$results = getUserNamesFromIDs($db,$user_ids);
	fyi($results);
}













































